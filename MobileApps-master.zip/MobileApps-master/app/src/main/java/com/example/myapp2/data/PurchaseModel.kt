package com.example.myapp2.data

import androidx.compose.ui.graphics.Color

class PurchaseModel (val name: String, val date: String, val price: Int, val color: Color)